package me.calo.islands.command;

import me.calo.islands.CaloIslandsPlugin;
import me.calo.islands.core.MessageService;
import me.calo.islands.goblin.GoblinItemService;
import me.calo.islands.goblin.GoblinVillageService;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import java.util.*;

public final class CaloIslandsCommand implements CommandExecutor, TabCompleter {
    private final CaloIslandsPlugin plugin; private final MessageService messages; private final GoblinVillageService goblin; private final GoblinItemService items;
    public CaloIslandsCommand(CaloIslandsPlugin plugin,MessageService messages,GoblinVillageService goblin,GoblinItemService items){ this.plugin=plugin;this.messages=messages;this.goblin=goblin;this.items=items; }
    @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] args){
        if(!sender.hasPermission("caloislands.admin")){messages.send(sender,"no-permission");return true;}
        if(args.length==0){help(sender);return true;}
        switch(args[0].toLowerCase(Locale.ROOT)){
            case "reload"->{plugin.reloadAll();messages.send(sender,"reloaded");}
            case "status"->status(sender);
            case "goblin"->goblin(sender,args);
            default->help(sender);
        }
        return true;
    }
    private void goblin(CommandSender sender,String[] args){
        if(args.length<2){help(sender);return;}
        switch(args[1].toLowerCase(Locale.ROOT)){
            case "start"->{if(goblin.start())messages.send(sender,"goblin-started");else messages.send(sender,"goblin-already-active");}
            case "stop"->{if(goblin.stop())messages.send(sender,"goblin-stopped");else messages.send(sender,"goblin-not-active");}
            case "status"->goblinStatus(sender);
            case "setcenter"->{if(!(sender instanceof Player p)){sender.sendMessage(messages.prefix()+"Solo un jugador puede usar este comando.");return;} goblin.setCenter(p.getLocation());messages.send(sender,"goblin-center-set");}
            case "give"->give(sender,args);
            default->help(sender);
        }
    }
    private void give(CommandSender sender,String[] args){
        if(!(sender instanceof Player p))return;
        if(args.length<4){sender.sendMessage(messages.prefix()+"/ci goblin give <piel|colmillo> <cantidad>");return;}
        int amount; try{amount=Math.max(1,Integer.parseInt(args[3]));}catch(NumberFormatException ex){amount=1;}
        if(args[2].equalsIgnoreCase("piel"))p.getInventory().addItem(items.piel(amount));
        else if(args[2].equalsIgnoreCase("colmillo"))p.getInventory().addItem(items.colmillo(amount));
    }
    private void status(CommandSender sender){ sender.sendMessage(messages.color("&6&lCaloIslands"));goblinStatus(sender);sender.sendMessage(messages.color("&8Necromancer: &7Pendiente"));sender.sendMessage(messages.color("&8Volcanic: &7Pendiente"));sender.sendMessage(messages.color("&8Slime: &7Pendiente"));sender.sendMessage(messages.color("&8Cerberus: &7Pendiente"));sender.sendMessage(messages.color("&8Golden Chest: &7Pendiente")); }
    private void goblinStatus(CommandSender sender){ if(!goblin.isActive()){sender.sendMessage(messages.color("&2Goblin Village: &cINACTIVA"));return;} long s=goblin.remainingSeconds();sender.sendMessage(messages.color("&2Goblin Village: &a"+goblin.state()+" &8| &f"+(s/60)+"m "+(s%60)+"s &8| &f"+goblin.participantCount()+" participantes")); }
    private void help(CommandSender sender){ sender.sendMessage(messages.color("&6&lCaloIslands"));sender.sendMessage(messages.color("&f/ci status"));sender.sendMessage(messages.color("&f/ci reload"));sender.sendMessage(messages.color("&f/ci goblin start"));sender.sendMessage(messages.color("&f/ci goblin stop"));sender.sendMessage(messages.color("&f/ci goblin status"));sender.sendMessage(messages.color("&f/ci goblin setcenter"));sender.sendMessage(messages.color("&f/ci goblin give <piel|colmillo> <cantidad>")); }
    @Override public List<String> onTabComplete(CommandSender sender,Command command,String alias,String[] args){ if(args.length==1)return match(args[0],List.of("status","reload","goblin")); if(args.length==2&&args[0].equalsIgnoreCase("goblin"))return match(args[1],List.of("start","stop","status","setcenter","give")); if(args.length==3&&args[1].equalsIgnoreCase("give"))return match(args[2],List.of("piel","colmillo")); return List.of(); }
    private List<String> match(String input,List<String> vals){ String l=input.toLowerCase(Locale.ROOT);List<String> out=new ArrayList<>();for(String v:vals)if(v.startsWith(l))out.add(v);return out; }
}
