package me.calo.islands;

import me.calo.islands.command.CaloIslandsCommand;
import me.calo.islands.core.MessageService;
import me.calo.islands.goblin.GoblinDropListener;
import me.calo.islands.goblin.GoblinItemService;
import me.calo.islands.goblin.GoblinVillageService;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class CaloIslandsPlugin extends JavaPlugin {
    private MessageService messages;
    private GoblinItemService goblinItems;
    private GoblinVillageService goblinVillage;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        saveResource("messages.yml", false);
        messages = new MessageService(this);
        goblinItems = new GoblinItemService(this);
        goblinVillage = new GoblinVillageService(this, messages, goblinItems);
        getServer().getPluginManager().registerEvents(new GoblinDropListener(this, goblinVillage), this);
        PluginCommand command = getCommand("caloislands");
        if (command != null) {
            CaloIslandsCommand executor = new CaloIslandsCommand(this, messages, goblinVillage, goblinItems);
            command.setExecutor(executor);
            command.setTabCompleter(executor);
        }
        goblinVillage.startScheduler();
        getLogger().info("CaloIslands habilitado correctamente.");
    }

    @Override
    public void onDisable() {
        if (goblinVillage != null) goblinVillage.shutdown();
    }

    public void reloadAll() {
        reloadConfig();
        messages.reload();
        goblinVillage.reload();
    }
}
